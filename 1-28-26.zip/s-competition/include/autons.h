#include "robot-config.h"
#include "vex.h"
#include "motor-control.h"
#include "dsr.h"

void splitLeft() {
    inertial_sensor.setHeading(0, degrees);
    all.setVelocity(100, percent);
    all.spin(forward);
    Drivetrain.setDriveVelocity(40, percent);

    curveCircle(-50, -13, 600, true);
    driveTo(19, 900, true);
    load = true;
    driveTo(5, 300, true);
    turnToAngle(-135, 600, true);
    intake.stop();
    driveTo(-19.5, 800, true);
    driveTo(-1, 10, false, 1);
    top.setVelocity(65, percent);
    top.spin(reverse);
    wait(1.3, seconds);
    load = true;
    driveTo(51, 1500, true);
    top.setVelocity(100, percent);
    top.spin(forward);
    turnToAngle(180, 500, true);
    //driveTo(16, 850, true, 6);
    wallDriveRight(16, 850, 9, 500, true);
    wait(0.2, seconds);
    wallDriveRight(-40, 800, 10, 500, true);
    driveTo(-1, 10, false, 4);
    all.spin(reverse);
    wing = true;
    wait(0.05, seconds);
    all.spin(forward);
    wait(2, seconds);
    curveCircle(90, -7, 700, true);
    wing = false;
    turnToAngle(167, 800, true);
    driveTo(-15, 1000, false, 5);
    turnToAngle(180, 200, false, 5);
    driveTo(-7.5, 1000, true, 5);
    driveTo(-1, 2000, false, 1);
}

void splitRight() {
    inertial_sensor.setHeading(0, degrees);
    all.setVelocity(100, percent);
    all.spin(forward);
    driveTo(-38, 1400, true);
    load = true;
    dsr(18.485, 400);
    turnToAngle(-90, 600, true);
    //driveTo(20, 800, true, 7);
    wallDriveLeft(20, 800, 9, 460, true);
    wait(0.15, seconds);
    //driveTo(-26.9, 550, true);
    wallDriveLeft(-40, 550, 12, 460, true);
    load = false;
    wing = true;
    driveTo(-1, 10, false, 4);
    wait(1.5, seconds);
    driveTo(20.25, 600, true);
    wing = false;
    turnToAngle(45, 600, true);
    driveTo(27.75, 800, true);
    load = true;
    driveTo(16, 800, true, 8);
    load = false;
    driveTo(5, 300, true, 8);
    all.stop();
    driveTo(5, 300, true, 8);
    all.spin(reverse);
    wait(0.5, seconds);
    intake.setVelocity(40, percent);
    all.spin(reverse);
    wait(0.75, seconds);
    all.setVelocity(100, percent);
    all.spin(forward);
    driveTo(-28.75, 1000, true);
    turnToAngle(100, 400, true);
    driveTo(25, 600, true, 7);
    turnToAngle(80, 200, true);
    driveTo(8, 600, true, 7);
    turnToAngle(50, 800, true);
}

void fullLeft() {

}

void fullRight() {
    
}

void sawp() {
    inertial_sensor.setHeading(0, degrees);
    all.setVelocity(100, percent);
    all.spin(forward);
    driveTo(-38, 1400, true);
    load = true;
    dsr(18.45, 500);
    turnToAngle(-90, 600, true);
    driveTo(20, 800, true);
    wait(0.25, seconds);
    driveTo(-26.9, 600, true);
    load = false;
    wing = true;
    driveTo(-1, 10, false, 5);
    wait(1, seconds);
    turnToAngle(10, 800, true);
    wing = false;
    driveTo(8, 450, true);
    driveTo(-2, 80, true);
    turnToAngle(0, 100, true);
    driveTo(3, 180, true, 9);
    driveTo(42.85, 1000, false);
    load = true;
    driveTo(8, 400, true, 7);
    wait(0.05, seconds);
    driveTo(-5, 200, true);
    turnToAngle(-45, 500, true);
    wait(0.05, seconds);
    driveTo(-26.9, 500, true);
    driveTo(-1, 10, false, 2);
    top.setVelocity(60, percent);
    top.spin(reverse);
    wait(0.9, seconds);
    turnToAngle(-45, 300, true);
    top.setVelocity(100, percent);
    driveTo(49, 2500, true);
    top.spin(forward);
    load = true;
    turnToAngle(-90, 500, true);
    driveTo(15, 600, true, 9);
    wait(0.25, seconds);
    driveTo(-26.5, 600, true);
    wing = true;
    all.spin(reverse);
    driveTo(-1, 10, false, 5);
    wait(0.2, seconds);
    all.spin(forward);
}