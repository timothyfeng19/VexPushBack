#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include "vex.h"
#include "autons.h"

using namespace vex;

// START V5 MACROS
#define waitUntil(condition)                                                   \
  do {                                                                         \
    wait(5, msec);                                                             \
  } while (!(condition))

#define repeat(iterations)                                                     \
  for (int iterator = 0; iterator < iterations; iterator++)
// END V5 MACROS

// AUTONOMOUS SELECTOR VARIABLES
int count = 0;
int autoCount = 0;
int selectedAuton = 0;
bool autonSelected = false;

const int NUM_AUTONS = 5;

const char* autonNames[] = {
  "Split Left",
  "Split Right", 
  "Full Left",
  "Full Right",
  "Solo AWP"
};

// generating and setting random seed
void initializeRandomSeed(){
  int systemTime = Brain.Timer.systemHighResolution();
  double batteryCurrent = Brain.Battery.current();
  double batteryVoltage = Brain.Battery.voltage(voltageUnits::mV);

  int seed = int(batteryVoltage + batteryCurrent * 100) + systemTime;
  srand(seed);
}

void playVexcodeSound(const char *soundName) {
  printf("VEXPlaySound:%s\n", soundName);
  wait(5, msec);
}

// AUTONOMOUS SELECTOR DISPLAY FUNCTIONS
void displayAutonSelector() {
  Brain.Screen.clearScreen();
  Brain.Screen.setPenColor(white);
  Brain.Screen.setFillColor(black);
  
  Brain.Screen.printAt(10, 30, "SELECT AUTONOMOUS");
  Brain.Screen.drawLine(10, 35, 470, 35);
  
  for(int i = 0; i < NUM_AUTONS; i++) {
    if(i == selectedAuton) {
      Brain.Screen.setFillColor(green);
      Brain.Screen.setPenColor(black);
    } else {
      Brain.Screen.setFillColor(vex::color(50, 50, 50));
      Brain.Screen.setPenColor(white);
    }
    
    Brain.Screen.drawRectangle(50, 60 + (i * 45), 380, 40);
    Brain.Screen.printAt(200, 85 + (i * 45), autonNames[i]);
  }
  
  Brain.Screen.setFillColor(black);
  Brain.Screen.setPenColor(white);
}

void displayConfirmation() {
  Brain.Screen.clearScreen();
  Brain.Screen.setPenColor(white);
  Brain.Screen.setFillColor(black);
  
  Brain.Screen.printAt(10, 30, "AUTONOMOUS SELECTED!");
  Brain.Screen.drawLine(10, 35, 470, 35);
  
  Brain.Screen.printAt(10, 70, "Auton:");
  Brain.Screen.printAt(80, 70, autonNames[selectedAuton]);
  
  char countStr[20];
  sprintf(countStr, "%d", count);
  
  Brain.Screen.printAt(10, 100, "count = ");
  Brain.Screen.printAt(100, 100, countStr);
  
  Brain.Screen.printAt(10, 140, "Ready for match start!");
}

void onScreenPressed() {
  int x = Brain.Screen.xPosition();
  int y = Brain.Screen.yPosition();
  
  if(!autonSelected) {
    if(x >= 50 && x <= 430 && y >= 60) {
      int index = (y - 60) / 45;
      if(index >= 0 && index < NUM_AUTONS) {
        selectedAuton = index;
        autonSelected = true;
      }
    }
  }
}

void configureAutonomous() {
  switch(selectedAuton) {
    case 0: // Split Left
      count = 1;
      break;
    case 1: // Split Right
      count = 2;
      break;
    case 2: // Full Left
      count = 3;
      break;
    case 3: // Full Right
      count = 4;
      break;
    case 4: // Solo AWP
      count = 5;
      break;
    default:
      count = 0;
      break;
  }
  
  autoCount = count;
}

void pre_auton(void) {
  displayAutonSelector();
  Brain.Screen.pressed(onScreenPressed);
  
  // Wait for user to select autonomous
  while(!autonSelected) {
    wait(20, msec);
  }
  
  // Give a moment after selection
  wait(300, msec);
  configureAutonomous();
  displayConfirmation();
}

// DRIVER CONTROL CODE
bool lpress = false;
bool apress = false;
bool upress = false;
bool hoard = false;

bool l = false;
bool r = false;
int display_buffer = 0;

void update() {
  controller_1.Screen.clearScreen();

  controller_1.Screen.setCursor(1,1);
  controller_1.Screen.print("Driver Control");

  controller_1.Screen.setCursor(2,1);
  if (hoard) {
    controller_1.Screen.print("Hoarding Enabled");
  } else {
    controller_1.Screen.print("Hoarding Disabled");
  }
  controller_1.Screen.setCursor(3,1);
  controller_1.Screen.print(Brain.Battery.capacity());
}

void telop() {
  update();
  while(true) {
    display_buffer += 1;
    if (display_buffer == 200) {
      update();
    }

    left_chassis.setStopping(coast);
    right_chassis.setStopping(coast);
    int left = controller_1.Axis3.position();
    int right = controller_1.Axis2.position();

    left_chassis.setVelocity(left, percent);
    right_chassis.setVelocity(right, percent);

    if (controller_1.ButtonR1.pressing()) {
      r = true;
      all.setVelocity(100, percent);
      if (hoard) {
        top.setVelocity(0, percent);
      }
      all.spin(forward);
    } else if (controller_1.ButtonR2.pressing()) {
      r = true;
      if (hoard) {
        hoard = false;
        update();
      }
      hoard = false;
      all.setVelocity(-100, percent);
      all.spin(forward);
    } else {
      r = false;
      if (!l) {
        all.stop();
      }
    }

    if (controller_1.ButtonL2.pressing()) {
      l = true;
      all.setVelocity(100, percent);
      all.spin(forward);
      top.spin(reverse);
    } else {
      l = false;
      if (!r) {
        all.stop();
      }
    }

    if (controller_1.ButtonL1.pressing()) {
      if(!lpress){
        wing = !wing;
        lpress = true;
        update();
      }
    } else {
      lpress = false;
    }

    if (controller_1.ButtonA.pressing()) {
      if (!apress) {
        load = !load;
        apress = true;
      }
    } else {
      apress = false;
    }

    if (controller_1.ButtonUp.pressing()) {
      if (!upress) {
        wing = !wing;
        upress = true;
      }
    } else {
      upress = false;
    }

    left_chassis.spin(forward);
    right_chassis.spin(forward);
    this_thread::sleep_for(20);
  }
}

// AUTONOMOUS CODE
void auton() {
  Brain.Screen.clearScreen();
  Brain.Screen.printAt(10, 30, "Running:");
  Brain.Screen.printAt(100, 30, autonNames[selectedAuton]);
  
  char countStr[20];
  sprintf(countStr, "%d", count);
  
  Brain.Screen.printAt(10, 60, "count = ");
  Brain.Screen.printAt(100, 60, countStr);
  
  // Call the appropriate autonomous function from autons.h
  switch(selectedAuton) {
    case 0:
      splitLeft();
      break;
    case 1:
      splitRight();
      break;
    case 2:
      fullLeft();
      break;
    case 3:
      fullRight();
      break;
    case 4:
      sawp();
      break;
  }
}

int main() {
  competition Competition = competition();
  Competition.autonomous(auton);
  Competition.drivercontrol(telop);
  
  // Run pre-autonomous selector
  pre_auton();
  
  // Prevent main from exiting
  while(true) {
    wait(100, msec);
  }
}