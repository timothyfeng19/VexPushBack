#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include "pid.h"
#include "motor-control.h"
#include "robot-config.h"
#include "utils.h"
#include "vex.h"
#include "dsr.h"

using namespace vex;

// Brain should be defined by default

// START V5 MACROS
#define waitUntil(condition)                                                   \
  do {                                                                         \
    wait(5, msec);                                                             \
  } while (!(condition))

#define repeat(iterations)                                                     \
  for (int iterator = 0; iterator < iterations; iterator++)
// END V5 MACROS


// Robot configuration code.



// generating and setting random seed
void initializeRandomSeed(){
  int systemTime = Brain.Timer.systemHighResolution();
  double batteryCurrent = Brain.Battery.current();
  double batteryVoltage = Brain.Battery.voltage(voltageUnits::mV);

  // Combine these values into a single integer
  int seed = int(batteryVoltage + batteryCurrent * 100) + systemTime;

  // Set the seed
  srand(seed);
}

// Helper to make playing sounds from the V5 in VEXcode easier and
// keeps the code cleaner by making it clear what is happening.
void playVexcodeSound(const char *soundName) {
  printf("VEXPlaySound:%s\n", soundName);
  wait(5, msec);
}


bool lpress = false;
bool apress = false;
bool upress = false;
bool hoard = false;

bool l = false;
bool r = false;
int display_buffer = 0;

void update() {
  controller_1.Screen.clearScreen();

  controller_1.Screen.setCursor(1,1);
  controller_1.Screen.print("Driver Control");

  controller_1.Screen.setCursor(2,1);
  if (hoard) {
    controller_1.Screen.print("Hoarding Enabled");
  } else {
    controller_1.Screen.print("Hoarding Disabled");
  }
  controller_1.Screen.setCursor(3,1);
  controller_1.Screen.print(Brain.Battery.capacity());
}

void telop() {
  update();
  while(true) {
    display_buffer += 1;
    if (display_buffer == 200) {
      update();
    }

    left_chassis.setStopping(coast);
    right_chassis.setStopping(coast);
    int left = controller_1.Axis3.position();
    int right = controller_1.Axis2.position();

    left_chassis.setVelocity(left, percent);
    right_chassis.setVelocity(right, percent);

    if (controller_1.ButtonR1.pressing()) {
      r = true;
      all.setVelocity(100, percent);
      if (hoard) {
        top.setVelocity(0, percent);
      }
      all.spin(forward);
    } else if (controller_1.ButtonR2.pressing()) {
      r = true;
      all.setVelocity(-20, percent);
      //intake.setVelocity(-50, percent);
      all.spin(forward);
    } else {
      r = false;
      if (!l) {
        all.stop();
      }
    }

    if (controller_1.ButtonL2.pressing()) {
      l = true;
      all.setVelocity(25, percent);
      top.setVelocity(30, percent);
      all.spin(forward);
      top.spin(reverse);
    } else {
      l = false;
      if (!r) {
        all.stop();
      }
    }

    if (controller_1.ButtonL1.pressing()) {
      if(!lpress){
        wing = !wing;
        lpress = true;
        update();
      }
    } else {
      lpress = false;
    }

    if (controller_1.ButtonA.pressing()) {
      if (!apress) {
        load = !load;
        apress = true;
      }
    } else {
      apress = false;
    }

    if (controller_1.ButtonUp.pressing()) {
      if (!upress) {
        wing = !wing;
        upress = true;
      }
    } else {
      upress = false;
    }

    left_chassis.spin(forward);
    right_chassis.spin(forward);
    this_thread::sleep_for(20);
  }
}

// Removed PID functions

int auton_buffer = 0;
int auton_buffer2 = 0;

void auton() {
    inertial_sensor.setHeading(90, degrees);
    all.setVelocity(100, percent);
    all.spin(forward);

    /*
    load = true;
    driveTo(37.5, 1400, true);
    correct_angle = normalizeAngle(-90);
    turnToAngle(-90, 500, true);
    driveTo(16, 800, true, 8);
    wait(0.3, seconds);
    driveTo(-2, 200, true);
    wait(0.3, seconds);
    driveTo(2, 300, true);
    wait(0.2, seconds);
    driveTo(-7, 400, true);
    load = false;
    
    all.stop();
    turnToAngle(0, 600, true);
    curveCircle(90, 12, 1100, false);
    correct_angle = normalizeAngle(90);
    driveTo(58, 3000, true);
    curveCircle(180, 15, 1100, false);
    dsr(18.5, 750);
    correct_angle = normalizeAngle(90);
    turnToAngle(90, 600, true);
    wallDrive(-40, 400, 12, 480, true);
    driveTo(-1, 10, false, 3);
    //driveTo(-10, 800, true);
    //driveTo(-1, 10, false, 5);
    wing = true;
    all.spin(forward);
    load = true;
    wait(2, seconds);
    turnToAngle(90, 600, true);
    driveTo(24, 800, true);
    wing = false;
    driveTo(12, 400, true, 8);
    wait(0.7, seconds);
    driveTo(-2, 200, true);
    wait(0.2, seconds);
    driveTo(2, 200, true);
    wait(0.5, seconds);

    //driveTo(-18, 1200, false);
    wallDrive(-40, 1200, 9, 480, true);
    wing = true;
    driveTo(-1, 10, false, 7);
    all.spin(forward);
    wait(2.6, seconds);
    load = false;
    */
    
    //park clear
    driveTo(20, 800, true);
    turnToAngle(135, 350, true);
    driveTo(20, 800, true);
    curveCircle(175, 10, 800, true);
    driveTo(3, 150, true);
    wing = false;
    driveTo(5, 1500, true, 5);
    correct_angle = normalizeAngle(75);
    driveTo(100, 2500, true, 8);
    curveCircle(-170, 4, 500, true);
    driveTo(-20, 800, true);
    turnToAngle(180, 100, true);
    driveTo(-10, 800, true, 4);
    curveCircle(-90, 6, 1300, true);
    driveTo(-1, 50, true);
    dsr(6, 300);
    driveTo(27, 800, true);
    wait(0.3, seconds);
    all.stop();
    turnToAngle(-135, 300, true);
    driveTo(10.75, 800, true);
    turnToAngle(135, 500, true);
    driveTo(-31, 1300, true, 8);
    all.spin(reverse);
    wait(0.15, seconds);
    all.setVelocity(40, percent);
    top.setVelocity(35, percent);
    all.spin(forward);
    top.spin(reverse);
    wait(4.5, seconds);
    driveTo(48.25, 2000, true);
    load = true;
    turnToAngle(90, 800, true);
    all.setVelocity(100, percent);
    
    all.spin(forward);
    correct_angle = normalizeAngle(90);
    driveTo(20, 1000, true, 8);
    wait(0.4, seconds);
    driveTo(-2, 200, true);
    wait(0.3, seconds);
    driveTo(2, 300, true);
    wait(0.2, seconds);
    driveTo(-7, 400, true);
    load = false;
    all.stop();
    turnToAngle(180, 600, true);
    curveCircle(-93, 12, 1100, false);
    turnToAngle(-93, 100, true);
    correct_angle = normalizeAngle(-95);

    //Drive to other side of far long goal
    driveTo(80, 3500, true);
    turnToAngle(0, 500, true);
    dsr(18.491, 1200);
    correct_angle = normalizeAngle(-90);
    turnToAngle(-90, 600, true);
    wallDrive(-40, 400, 12, 480, true);
    driveTo(-1, 10, false, 5);
    wing = true;
    all.spin(forward);
    load = true;
    wait(2, seconds);
    turnToAngle(-90, 600, true);
    driveTo(23, 1150, true);
    wing = false;
    driveTo(12, 750, true, 9);
    //Last Matchload
    wait(0.5, seconds);
    driveTo(-2, 200, true);
    wait(0.2, seconds);
    driveTo(2, 200, true);
    wait(0.5, seconds);
    wallDrive(-40, 1000, 10, 480, true);
    wing = true;
    driveTo(-1, 10, false, 7);
    all.spin(forward);
    wait(2.2, seconds);
    load = false;
    curveCircle(-5, 36.5, 2000, true);
    wing = false;

    driveTo(35, 4000, true);
    load = false;
}

int main() {
  competition Competition = competition();
  Competition.autonomous(auton);
  Competition.drivercontrol(telop);
  return (0);
}